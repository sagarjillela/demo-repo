package com.ata.bean;


import java.util.Date;

import javax.persistence.*;
import lombok.Data;

@Entity
@Table(name="profilebean")
@Data
public class ProfileBean {

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	private String userID;
	private String firstName;
	private String lastName;
	private Date datofBirth;
	private String gender;
	private String street;
	private String location;
	private String city;
	private String state;
	private String pincode;
	private String mobileNo;
	private String emailId;
	private String password;
}
	