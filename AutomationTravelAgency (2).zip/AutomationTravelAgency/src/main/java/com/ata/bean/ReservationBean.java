package com.ata.bean;



import javax.persistence.*;
import lombok.Data;
import java.util.Date;


@Entity
@Table(name="ReservationBean")
@Data
public class ReservationBean {
	@Id




	private String reservationID;	
	private String userID	;
	private String routeID	;
	private Date bookingDate	;
	private Date journeyDate;	
	private String vehicleID;	
	private String driverID;
 

	private String bookingStatus;	
	private double totalFare	;
	private String boardingPoint;	
	private String dropPoint	;


}
