package com.ata.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ata.dao.*;
//import com.trainee.model.Trainee;
import com.ata.bean.*;


@Service

public class AdminService{
	
	@Autowired
	
	//private AdminAtaRepo adminrepo;
	private AdminAtaRepo1 adminrepo1;
	@Autowired
	private AdminAtaRepo2 adminrepo2;
	private AdminAtaRepo3 adminrepo3;
	
	public List<VehicleBean> fetchVehicleList() {
		return (List<VehicleBean>) adminrepo1.findAll();
	}

	public VehicleBean addVehicle(VehicleBean vehiclebean) {

		return adminrepo1.save(vehiclebean);
	}

	public int deleteVehicle(String vehicleID) {
		adminrepo1.deleteById(vehicleID);
		return 0;
	}

	public List<VehicleBean> viewVehicle(String vehicleID) {

		return (List<VehicleBean>) adminrepo1.findByVehicleID(vehicleID);

	}

	public boolean modifyVehicle(VehicleBean vehicleBean) {
		 adminrepo1.save(vehicleBean);
		 return true;
	}

	public DriverBean addDriver(DriverBean driverBean) {

		return  adminrepo3.save(driverBean);
	}

	public int deleteDriver(String driverID) {
		adminrepo3.deleteById(driverID);

		return 0;
	}

	/*public List<DriverBean> viewDriver(String DriverID) {

		return (List<DriverBean>) adminrepo3.findByDriverID(DriverID);
	}
*/
//	public boolean allotDriver(String reservationID, String driverID) {
//		return false;
//	}

//	@Override
	public boolean modifyDriver(DriverBean driverBean) {
		 adminrepo3.save(driverBean);

		return true;
	}

	//@Override
	public String addRoute(RouteBean routeBean) {
		adminrepo2.save(routeBean);
		return null;
	}

//	@Override
	public int deleteRoute(String routeID) {
		adminrepo2.deleteById(routeID);

		return 0;
	}

	//@Override
	public List<RouteBean> viewRoute(String routeID) {
		return (List<RouteBean>) adminrepo2.findByRouteID(routeID);
	}

	//@Override
	public boolean modifyRoute(RouteBean routeBean) {
		 adminrepo2.save(routeBean);
		 return false;
	}

	//@Override
//	public ArrayList<ReservationBean> viewBookingDetails(Date journeyDate, String source, String destination) {
	//	return null;
//	}

}