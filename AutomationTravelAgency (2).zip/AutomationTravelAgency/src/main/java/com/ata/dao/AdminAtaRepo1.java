package com.ata.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.ata.service.*;
//import com.trainee.model.Trainee;
import com.ata.bean.*;


public interface AdminAtaRepo1 extends CrudRepository<VehicleBean,String> {
	List<VehicleBean> findByVehicleID(String vehicleID);


	
	
	}

