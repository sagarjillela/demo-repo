package com.ata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutomationTravelAgencyApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutomationTravelAgencyApplication.class, args);
	}

}
