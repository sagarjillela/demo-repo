package com.ata.controller;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.ata.exception.*;


import com.ata.bean.*;
import com.ata.service.AdminService;
//import com.trainee.exception.TraineeListEmptyException;
//import com.trainee.model.Trainee;


  
@RestController
  
public class AdminController1 {
  
    @Autowired 
    AdminService adminservice;
    
    
    
    
    
    
    //  VEHICLEBEAN OPERATIONS
    
    
    
    
    
    
    
    @GetMapping(value="/vehicles")
    public List<VehicleBean> fetchVehicleList() 
    {     
  	 
  	 if(adminservice.fetchVehicleList().isEmpty())   throw new NotFoundException();

  		System.out.println("Fetched successfully");

  	 	return adminservice.fetchVehicleList();
     }

   
    
	
	@PostMapping(value= "/vehicle/addvehicle")
    public String addVehicle(@RequestBody VehicleBean vehiclebean)
  { 
		adminservice.addVehicle(vehiclebean);
		System.out.println("Created successfully");
		return "Created successfully";
   }
	  @DeleteMapping(value="/vehicle/delete/{vehicleID}")
	   public String deleteVehicle(@PathVariable("vehicleID")String vehicleID)
	   {
		  adminservice.deleteVehicle(vehicleID);

	       return "Deleted Successfully";
	 }
	  @GetMapping(value= "/vehicle/vehicleid/{vehicleID}")

	  public List<VehicleBean> viewVehicle(@PathVariable("vehicleID")String vehicleID)
	   { 
			
	   if(adminservice.viewVehicle(vehicleID).isEmpty())  throw new NotFoundException();
	 

	   System.out.println("Fetched Successfully");
	   return adminservice.viewVehicle(vehicleID);

	   }
	  @PutMapping(path="/vehicle/update",consumes= {"application/json"})

	   public boolean modifyVehicle(@RequestBody VehicleBean vehiclebean)

	   {

		  adminservice.modifyVehicle(vehiclebean);
	      System.out.println("Updated Sucessfully");
	      return true;

	   }
	  
	  
	  
	  
	  
	    //  DRIVERBEAN OPERATIONS

	  
	  
	  
	  
	  
	  
	  
	  
	  
		@PostMapping(value= "/Driver/addDriver")
	    public String addDriver(@RequestBody DriverBean driverbean)
	  { 
			adminservice.addDriver(driverbean);
			System.out.println("Created successfully");
			return "Created successfully";
	   }
		  @DeleteMapping(value="/Driver/delete/{driverID}")
		   public String deleteDriver(@PathVariable("driverID") String driverID)
		   {
			  adminservice.deleteDriver(driverID);

		       return "Deleted Successfully";
		 }
		  @GetMapping(value= "/Driver/DriverID/{reservationID}/{driverID}")

		/*  public boolean allotDriver(@PathVariable("driverID") String reservationID, String driverID)
		   { 
			  if(adminservice.viewDriver(driverID).isEmpty())  throw new NotFoundException();
				
		   adminservice.allotDriver(reservationID,driverID);

		   System.out.println("Allotted Successfully");
		   return true;

		   }*/
		  @PutMapping(path="/Driver/update",consumes= {"application/json"})

		   public boolean modifyDriver(@RequestBody DriverBean driverbean)

		   {

			  adminservice.modifyDriver(driverbean);
		      System.out.println("Updated Sucessfully");
		      return true;

		   }
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		    //  ROUTEBEAN OPERATIONS

		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
			@PostMapping(value= "/Route/addroute")
		    public String addRoute(@RequestBody RouteBean routebean)
		  { 
				adminservice.addRoute(routebean);
				System.out.println("Created successfully");
				return "Created successfully";
		   }
			  @DeleteMapping(value="/vehicle/delete/{routeID}")
			   public String deleteRoute(@PathVariable("routeID") String routeID)
			   {
				  adminservice.deleteRoute(routeID);

			       return "Deleted Successfully";
			 }
			  @GetMapping(value= "/Route/RouteID/{routeID}")

			  public List<RouteBean> viewRoute(@PathVariable("routeID")String routeID)
			   { 
					
			   if(adminservice.viewRoute(routeID).isEmpty())  throw new NotFoundException();
			 

			   System.out.println("Fetched Successfully");
			   return adminservice.viewRoute(routeID);

			   }
			
			  @PutMapping(path="/route/update",consumes= {"application/json"})

			   public boolean modifyRoute(@RequestBody RouteBean routebean)

			   {

				  adminservice.modifyRoute(routebean);
			      System.out.println("Updated Sucessfully");
			      return true;

			   }
			  
			
				

		
			

		
	}
