package com.ata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutomationTravelAgencyApplicationTests {

	@Test
	void contextLoads() {
	}

}
